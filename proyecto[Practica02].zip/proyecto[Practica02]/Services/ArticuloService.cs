﻿using proyecto_Practica02_.Models;
using proyecto_Practica02_.Repositories.Contracts;

namespace proyecto_Practica02_.Services
{
    public class ArticuloService : IArticulo
    {
        private readonly IArticuloRepository _articuloRepository;

        public ArticuloService(IArticuloRepository articuloRepository)
        {
            _articuloRepository = articuloRepository;
        }

        public IEnumerable<Articulo> ObtenerArticulos()
        {
            return _articuloRepository.ObtenerArticulos();
        }

        public Articulo ObtenerArticuloPorId(int id)
        {
            return _articuloRepository.ObtenerArticuloPorId(id);
        }

        public void AgregarArticulo(Articulo articulo)
        {
            _articuloRepository.AgregarArticulo(articulo);
        }

        public void EditarArticulo(Articulo articulo)
        {
            _articuloRepository.EditarArticulo(articulo);
        }

        public void BorrarArticulo(int id)
        {
            _articuloRepository.BorrarArticulo(id);
        }
    }
}
