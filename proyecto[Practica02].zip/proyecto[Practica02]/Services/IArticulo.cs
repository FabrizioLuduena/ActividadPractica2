﻿using proyecto_Practica02_.Models;
namespace proyecto_Practica02_.Services
{
    public interface IArticulo
    {
        IEnumerable<Articulo> ObtenerArticulos();
        Articulo ObtenerArticuloPorId(int id);
        void AgregarArticulo(Articulo articulo);
        void EditarArticulo(Articulo articulo);
        void BorrarArticulo(int codigo);
    }
}
