﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using proyecto_Practica02_.Models;
using proyecto_Practica02_.Services;

namespace proyecto_Practica02_.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ArticulosController : ControllerBase
    {
        private readonly IArticulo _articulo;

        public ArticulosController(IArticulo articulo)
        {
            _articulo = articulo;
        }

        [HttpGet]
        public ActionResult<IEnumerable<Articulo>> ObtenerArticulos()
        {
            return Ok(_articulo.ObtenerArticulos());
        }

        [HttpGet("{id}")]
        public ActionResult<Articulo> ObtenerArticuloPorId(int id)
        {
            var articulo = _articulo.ObtenerArticuloPorId(id);
            if (articulo == null)
            {
                return NotFound();
            }
            return Ok(articulo);
        }

        [HttpPost]
        public ActionResult AgregarArticulo(Articulo articulo)
        {
            _articulo.AgregarArticulo(articulo);
            return CreatedAtAction(nameof(ObtenerArticuloPorId), new { id = articulo.IdArticulo }, articulo);
        }

        [HttpPut("{id}")]
        public ActionResult EditarArticulo(int id, Articulo articulo)
        {
            if (id != articulo.IdArticulo)
            {
                return BadRequest();
            }
            _articulo.EditarArticulo(articulo);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public ActionResult BorrarArticulo(int id)
        {
            _articulo.BorrarArticulo(id);
            return NoContent();
        }


    }
}
