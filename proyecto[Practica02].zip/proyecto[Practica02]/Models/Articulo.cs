﻿using proyecto_Practica02_.Services;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace proyecto_Practica02_.Models
{
    public class Articulo
    {
        private int idArticulo;
        private string nombre;
        private int precioUnitario;

        public Articulo()
        {
            nombre = string.Empty;
            precioUnitario = 0;
        }
        public Articulo(string nombre, int precioUnitario)
        {
            this.nombre = nombre;
            this.precioUnitario = precioUnitario;
        }
        public int IdArticulo
        {
            get { return idArticulo; }
            set { idArticulo = value; }
        }
        public int PrecioUnitario
        {
            get { return precioUnitario; }
            set { precioUnitario = value; }
        }

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        public override string ToString()
        {
            return nombre + "; $" + precioUnitario;
        }
    }
}
