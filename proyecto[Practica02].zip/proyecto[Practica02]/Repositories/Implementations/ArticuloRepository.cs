﻿using proyecto_Practica02_.Repositories.Contracts;
using proyecto_Practica02_.Models;
using System.Collections.Generic;
using System.Data;
using proyecto_Practica02_.Controllers.Utils;
using System.Data.SqlClient;
using proyecto_Practica02_.Services;
namespace proyecto_Practica02_.Repositories.Implementations
{
    public class ArticuloRepository : IArticuloRepository
    {
        private readonly string _connectionString;

        public ArticuloRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        public IEnumerable<Articulo> ObtenerArticulos()
        {
            List<Articulo> articulos = new List<Articulo>();
            DataTable? table = new DataTable();
            table = DataHelper.GetInstance().ExecuteSPQuery("SP_ARTICULO_TODO", null);
            if (table != null)
            {
                foreach (DataRow row in table.Rows)
                {
                    Articulo a = new Articulo();
                    a.IdArticulo = (int)row[0];
                    a.Nombre = (string)row[1];
                    a.PrecioUnitario = (int)row[2];
                    articulos.Add(a);
                }
            }
            return articulos;
        }

        public Articulo ObtenerArticuloPorId(int id)
        {
            Articulo a = new Articulo();
            DataTable? table = new DataTable();
            table = DataHelper.GetInstance().ExecuteSPQuery("SP_ARTICULO_ID", new List<ParameterSQL>() { new ParameterSQL("id", id) });
            DataRow row = table.Rows[0];
            a.IdArticulo = (int)row[0];
            a.Nombre = (string)row[1];
            a.PrecioUnitario = (int)row[2];
            return a;
        }

        public void AgregarArticulo(Articulo articulo)
        {
            List<ParameterSQL> parameters = new List<ParameterSQL>()
            {
                new ParameterSQL("Nombre",articulo.Nombre),
                new ParameterSQL("PrecioUnitario", articulo.PrecioUnitario)
            };
            int rows = DataHelper.GetInstance().ExecuteSPDML("SP_ARTICULO_CREAR", parameters);
        }

        public void EditarArticulo(Articulo articulo)
        {
            List<ParameterSQL> parameters = new List<ParameterSQL>()
            {
                new ParameterSQL("IdArticulo", articulo.IdArticulo),
                new ParameterSQL("Nombre",articulo.Nombre),
                new ParameterSQL("PrecioUnitario", articulo.PrecioUnitario)
            };
            int rows = DataHelper.GetInstance().ExecuteSPDML("SP_ARTICULO_EDITAR", parameters);
        }
        

        public void BorrarArticulo(int id)
        {
            var parametros = new List<ParameterSQL>
            {
                new ParameterSQL("IdArticulo", id)
            };
            int result = DataHelper.GetInstance().ExecuteSPDML("SP_ARTICULO_BORRAR", parametros);

            if (result == 0)
            {
                throw new Exception("No se pudo borrar el artículo o no existe.");
            }
        }
    }
}
