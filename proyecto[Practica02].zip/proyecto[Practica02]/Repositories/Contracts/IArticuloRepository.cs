﻿using proyecto_Practica02_.Models;

namespace proyecto_Practica02_.Repositories.Contracts
{
    public interface IArticuloRepository
    {
        public IEnumerable<Articulo> ObtenerArticulos();
        public Articulo ObtenerArticuloPorId(int id);
        public void AgregarArticulo(Articulo articulo);
        public void EditarArticulo(Articulo articulo);
        public void BorrarArticulo(int id);

    }
}
